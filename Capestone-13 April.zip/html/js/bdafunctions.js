var Web3 = require('web3');
var web3 = new Web3();
var providerURL = "HTTP://127.0.0.1:7545";
var contractAddress = "0x116c92ce34419d7abd46da465d49a30b6828c21c";
var abi = [{"constant":true,"inputs":[],"name":"contractOwner","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":true,"inputs":[{"name":"_id","type":"bytes32"}],"name":"getLand","outputs":[{"name":"","type":"string"},{"name":"","type":"string"},{"name":"","type":"uint256"},{"name":"","type":"string"}],"payable":false,"stateMutability":"view","type":"function"},{"constant":false,"inputs":[{"name":"_id","type":"bytes32"},{"name":"_forestAuthority","type":"string"},{"name":"_reasonForRejection","type":"string"}],"name":"forestAuthorityApproval","outputs":[{"name":"","type":"bool"}],"payable":true,"stateMutability":"payable","type":"function"},{"constant":false,"inputs":[{"name":"_newOwnerAddress","type":"address"}],"name":"changeContractOwner","outputs":[],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_location","type":"string"},{"name":"_name","type":"string"},{"name":"_id","type":"bytes32"},{"name":"_surveyNumber","type":"uint256"}],"name":"submitNOC","outputs":[{"name":"","type":"bool"}],"payable":true,"stateMutability":"payable","type":"function"},{"constant":false,"inputs":[{"name":"_id","type":"bytes32"}],"name":"overallApprovalStatus","outputs":[{"name":"","type":"bool"},{"name":"","type":"string"},{"name":"","type":"string"},{"name":"","type":"string"},{"name":"","type":"string"}],"payable":true,"stateMutability":"payable","type":"function"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_id","type":"bytes32"},{"indexed":false,"name":"_forestAuthority","type":"string"},{"indexed":false,"name":"_reasonForRejection","type":"string"}],"name":"eveForestAuthorityApproval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"name":"_id","type":"bytes32"},{"indexed":false,"name":"_lakeAuthority","type":"string"},{"indexed":false,"name":"_reasonForRejection","type":"string"}],"name":"eveLakeAuthorityApproval","type":"event"},{"anonymous":false,"inputs":[{"indexed":false,"name":"_projLocation","type":"string"},{"indexed":false,"name":"_name","type":"string"},{"indexed":true,"name":"_id","type":"bytes32"},{"indexed":true,"name":"_surveyNumber","type":"uint256"},{"indexed":false,"name":"_nocStatus","type":"string"}],"name":"eveSubmitNOC","type":"event"},{"constant":false,"inputs":[{"name":"_location","type":"string"},{"name":"_name","type":"string"},{"name":"_id","type":"bytes32"},{"name":"_surveyNumber","type":"uint256"}],"name":"setLand","outputs":[{"name":"","type":"address"}],"payable":false,"stateMutability":"nonpayable","type":"function"},{"constant":false,"inputs":[{"name":"_id","type":"bytes32"},{"name":"_lakeAuthority","type":"string"},{"name":"_reasonForRejection","type":"string"}],"name":"lakeAuthorityApproval","outputs":[{"name":"","type":"bool"}],"payable":true,"stateMutability":"payable","type":"function"}];

//Empty Declarations
var MyContract, myContractInstance;

function connectToNetwork() {
    web3.setProvider(new web3.providers.HttpProvider(providerURL)); 
	console.log("Connected to network");
}

function connectToContract() {
	MyContract = web3.eth.contract(abi);
	myContractInstance = MyContract.at(contractAddress);
	console.log("connect to contract");
}

function readABI(_jsonFileName) { 
	var fs = require('fs');
	var jsonFile = "contract/"+_jsonFileName+".json";
	var parsed= JSON.parse(fs.readFileSync(jsonFile));
	var abi = parsed.abi;
	console.log("ABI Loaded is - " + abi);
	
	return abi;
	//var YourContract= new web3.eth.Contract(abi, 0x12345678912345678912345678912345678912);
}


