function connect(_providerURL, _abi) {
	var Web3 = require('web3');
    var web3 = new Web3();
    web3.setProvider(new web3.providers.HttpProvider(_providerURL)); 
	var abi = _abi;
	console.log("Connecting to provider " + _providerURL + " to ABI "  + _abi);
	
	return web3;
}

function readABI(_jsonFileName) { 
	var fs = require('fs');
	var jsonFile = "contract/"+_jsonFileName+".json";
	var parsed= JSON.parse(fs.readFileSync(jsonFile));
	var abi = parsed.abi;
	console.log("ABI Loaded is - " + abi);
	
	return abi;
	//var YourContract= new web3.eth.Contract(abi, 0x12345678912345678912345678912345678912);
}