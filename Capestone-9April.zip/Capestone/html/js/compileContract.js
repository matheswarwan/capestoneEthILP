const solc = require('solc');
const fs = require('fs');

const contractName = 'Adder';
const contractFile = 'Adder.sol';

const contract = fs.readFileSync(contractFile).toString();
let input = {};

input[contractFile] = contract;

const output = solc.compile({sources: input}, 1);

const artifacts = {
    bytecode: output.contracts[contractFile + ":" + contractName].bytecode,
    abi: output.contracts[contractFile + ":" + contractName].interface,
}

fs.writeFileSync('compiledContracts.json', JSON.stringify(artifacts, null, 2))