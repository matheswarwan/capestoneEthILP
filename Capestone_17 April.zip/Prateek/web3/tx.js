const Web3 = require('web3');
const fs = require('fs');
const compiledContract = JSON.parse(fs.readFileSync('compiledContracts.json'));

const web3 = new Web3(new Web3.providers.HttpProvider("http://localhost:8000"));

web3.eth.getAccounts().then((accounts) => {
    if(process.argv[2] == 'tx') {
        tx(web3, accounts);
    } else if(process.argv[2] == 'contract') {
        contract(web3, accounts);
    } else if(process.argv[2] == 'contractTx') {
        contractTx(web3, accounts, process.argv[3]);
    } else if(process.argv[2] == 'contractCall') {
        contractCall(web3, accounts, process.argv[3]);
    } else if(process.argv[2] == 'filter') {
        filter(web3, accounts, process.argv[3]);
    }
});

const tx = (web3, accounts) => {
    web3.eth.sendTransaction({
        from: accounts[0],
        to: accounts[1],
        value: 10000000
    }, (err, result) => {
        console.log(err, result);
        console.log(`result from callback is above`)
    }).then(console.log);
}

const contract = (web3, accounts) => {
    const contractInstance = new web3.eth.Contract(JSON.parse(compiledContract.abi));

    contractInstance.deploy({
        data: compiledContract.bytecode
    }).send({
        from: accounts[0],
        gas: 4000000
    }, (err, txHash) => {
        console.log(err, txHash);
    }).on('error', (err) => {
        console.log(err);
    }).on('transactionHash', (txHash) => {
        console.log(txHash);
    }).on('receipt', (receipt) => {
        console.log(receipt)
    }).then((newContractInstance) => {
        console.log(newContractInstance)
        // console.log("contract instance created " + newContractInstance)
    })
}

const contractTx = (web3, accounts, contractAddress) => {
    const contractInstance = new web3.eth.Contract(JSON.parse(compiledContract.abi), contractAddress);
    contractInstance.methods.add(4).send({from: accounts[0]}, (err, txHash) =>{
        console.log(err, txHash);
    }).on('error', (err) => {
        console.log(err);
    }).on('transactionHash', (txHash) => {
        console.log(txHash);
    }).on('receipt', (receipt) => {
        console.log(receipt)
    }).then((txReceipt) => {
        console.log(txReceipt)
    })
}

const contractCall = (web3, accounts, contractAddress) => {
    const contractInstance = new web3.eth.Contract(JSON.parse(compiledContract.abi), contractAddress);
    contractInstance.methods.total().call()
    .then(console.log)
};

const filter = (web3, accounts, contractAddress) => {
    web3.setProvider("ws://localhost:8000");
    const subscription = web3.eth.subscribe("logs", {
        address: contractAddress
    }, (err, log) => {
        if(!err) {
            console.log("event filtered below")
            console.log(log);
        }
    });

    contractTx(web3, accounts, contractAddress);

    setTimeout(() => {
        subscription.unsubscribe((err, success) => {
            if(success) {
                console.log('Successfully unsubscribed');
            }
        })
    }, 100000)
}